using System;
using System.Data.SQLite;

namespace MediaManager
{
    public class Model
    {
        
    }
}